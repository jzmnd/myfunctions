#!/usr/bin/env python

from distutils.core import setup

setup(name = 'myfunctions',
	version = '1.0',
	author = 'Jeremy Smith',
	author_email = 'j.smith07@imperial.ac.uk',
	url = 'http://www3.imperial.ac.uk/',
	py_modules = ['myfunctions'],
	)
