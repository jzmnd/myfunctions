#!/usr/bin/env python

from distutils.core import setup

setup(name = 'myfunctions',
	version = '2.2',
	author = 'Jeremy Smith',
	author_email = 'j-smith@eecs.berkeley.edu',
	url = 'http://ink.eecs.berkeley.edu',
	py_modules = ['myfunctions'],
	)
