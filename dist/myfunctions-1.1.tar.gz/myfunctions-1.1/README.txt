Some useful functions by Jeremy Smith

Function List:

numInt(function, a, b, step)
numDiff(y, x)
mean_sterr(x)
paImport(datafile, path, ext_cut=6)
paramImport(paramfile, path, param_no=3)
