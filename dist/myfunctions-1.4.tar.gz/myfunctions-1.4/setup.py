#!/usr/bin/env python

from distutils.core import setup

setup(name = 'myfunctions',
	version = '1.4',
	author = 'Jeremy Smith',
	author_email = 'jeremy.smith@imperial.ac.uk',
	url = 'http://chemgroups.northwestern.edu/marks/',
	py_modules = ['myfunctions'],
	)
