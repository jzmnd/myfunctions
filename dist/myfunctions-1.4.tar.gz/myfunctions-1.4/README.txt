Some useful functions by Jeremy Smith

Function List:

numInt(function, a, b, step)
numDiff(y, x)
mean_sterr(x)
paImport(datafile, path, ext_cut=6)
paramImport(paramfile, path, param_no=3)
dataOutput(filename, path, datalist, format="%.1f\t %e\t %e\t %e\n")
quickPlot(filename, path, datalist, xlabel="x", ylabel="y", xrange=["auto", "auto"], yrange=["auto", "auto"], yscale="linear", xscale="linear", col=["r","b"])
paImportLV(datafile, path, ext_cut=7)
outputMultiList(data)
paImportImpSpec(datafile, path, ext_cut=9)
